package com.example.mauricesapppingpointproject2;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.Manifest;
import android.content.ContentValues;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.util.ArrayList;

public class DatabaseActivity extends AppCompatActivity {

    RecyclerView recyclerView;
    InventoryAdapter adapter;
    ArrayList<InventoryItem> inventoryList;
    DatabaseHelper databaseHelper;

    Button addItemButton, smsButton;

    private static final int SMS_PERMISSION_CODE = 100;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_database);

        // Grab views
        recyclerView = findViewById(R.id.dataRecyclerView);
        addItemButton = findViewById(R.id.addItemButton);
        smsButton = findViewById(R.id.smsButton);

        // Database helper
        databaseHelper = new DatabaseHelper(this);

        // Set up RecyclerView and adapter
        inventoryList = new ArrayList<>();
        adapter = new InventoryAdapter(inventoryList, (item, position) -> deleteItemFromDatabase(item.getId()));
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(adapter);

        // Load existing inventory items
        loadInventoryItems();

        // Add item button
        addItemButton.setOnClickListener(v -> showAddItemDialog());

        // SMS button opens SmsActivity
        smsButton.setOnClickListener(v -> {
            Intent intent = new Intent(DatabaseActivity.this, SmsActivity.class);
            startActivity(intent);
        });
    }

    // Load items from database
    private void loadInventoryItems() {
        inventoryList.clear();
        SQLiteDatabase db = databaseHelper.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM inventory", null);

        while (cursor.moveToNext()) {
            int id = cursor.getInt(cursor.getColumnIndexOrThrow("id"));
            String name = cursor.getString(cursor.getColumnIndexOrThrow("item_name"));
            inventoryList.add(new InventoryItem(id, name));
        }

        cursor.close();
        adapter.notifyDataSetChanged();
    }

    // Show dialog to add new item
    private void showAddItemDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Add New Item");

        EditText input = new EditText(this);
        input.setHint("Enter item name");
        builder.setView(input);

        builder.setPositiveButton("Add", (dialog, which) -> {
            String itemName = input.getText().toString().trim();
            if (!itemName.isEmpty()) {
                addItemToDatabase(itemName);
            } else {
                Toast.makeText(DatabaseActivity.this,
                        "Item name cannot be empty", Toast.LENGTH_SHORT).show();
            }
        });

        builder.setNegativeButton("Cancel", (dialog, which) -> dialog.dismiss());
        builder.show();
    }

    // Add item to database and send SMS if permission granted
    private void addItemToDatabase(String itemName) {
        SQLiteDatabase db = databaseHelper.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("item_name", itemName);

        long result = db.insert("inventory", null, values);
        if (result != -1) {
            Toast.makeText(this, "Item added", Toast.LENGTH_SHORT).show();
            loadInventoryItems();

            // Try to send SMS if permission is granted
            if (checkSmsPermission()) {
                sendSms("New inventory item added: " + itemName);
            } else {
                requestSmsPermission();
            }

        } else {
            Toast.makeText(this, "Error adding item", Toast.LENGTH_SHORT).show();
        }
    }

    // Delete item from database
    private void deleteItemFromDatabase(int id) {
        SQLiteDatabase db = databaseHelper.getWritableDatabase();
        int result = db.delete("inventory", "id=?", new String[]{String.valueOf(id)});

        if (result > 0) {
            Toast.makeText(this, "Item deleted", Toast.LENGTH_SHORT).show();
            loadInventoryItems();
        } else {
            Toast.makeText(this, "Error deleting item", Toast.LENGTH_SHORT).show();
        }
    }

    // Check SMS permission
    private boolean checkSmsPermission() {
        return ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                == PackageManager.PERMISSION_GRANTED;
    }

    // Request SMS permission
    private void requestSmsPermission() {
        ActivityCompat.requestPermissions(this,
                new String[]{Manifest.permission.SEND_SMS},
                SMS_PERMISSION_CODE);
    }

    // Handle permission result
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions,
                                           @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == SMS_PERMISSION_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(this, "SMS permission granted", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "SMS permission denied", Toast.LENGTH_SHORT).show();
            }
        }
    }

    // Send SMS
    private void sendSms(String message) {
        try {
            SmsManager smsManager = SmsManager.getDefault();
            String phoneNumber = "1234567890"; // Replace with test number
            smsManager.sendTextMessage(phoneNumber, null, message, null, null);
            Toast.makeText(this, "SMS sent: " + message, Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            Toast.makeText(this, "Failed to send SMS", Toast.LENGTH_SHORT).show();
            e.printStackTrace();
        }
    }
}
