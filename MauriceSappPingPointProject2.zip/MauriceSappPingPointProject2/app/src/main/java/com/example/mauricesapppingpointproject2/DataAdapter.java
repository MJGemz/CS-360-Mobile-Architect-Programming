package com.example.mauricesapppingpointproject2;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class DataAdapter extends RecyclerView.Adapter<DataAdapter.ViewHolder> {

    // I keep track of the data I want to show in the RecyclerView
    ArrayList<String> dataList;

    // I pass the data into the adapter when I create it
    public DataAdapter(ArrayList<String> dataList) {
        this.dataList = dataList;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        // I inflate each row layout from XML (data_item.xml)
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.data_item, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        // I set the text for each item
        holder.itemText.setText(dataList.get(position));

        // I handle deleting an item if the user clicks the delete button
        holder.deleteButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // I remove the item from my list
                dataList.remove(position);
                // I notify the adapter so the list updates
                notifyItemRemoved(position);
                notifyItemRangeChanged(position, dataList.size());
            }
        });
    }

    @Override
    public int getItemCount() {
        // I return how many items are in my list
        return dataList.size();
    }

    // This is my ViewHolder class to hold references to the views in each row
    public static class ViewHolder extends RecyclerView.ViewHolder {
        TextView itemText;
        Button deleteButton;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            // I grab the text and delete button from the row layout
            itemText = itemView.findViewById(R.id.itemText);
            deleteButton = itemView.findViewById(R.id.deleteButton);
        }
    }
}
