package com.example.mauricesapppingpointproject2;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class SmsActivity extends AppCompatActivity {

    // I have a button to request permission and a text view to show status
    Button requestPermissionButton;
    TextView permissionStatus;

    private static final int SMS_PERMISSION_CODE = 101;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // I link this activity to the XML layout
        setContentView(R.layout.activity_sms);

        // I get references to my button and textview
        requestPermissionButton = findViewById(R.id.requestPermissionButton);
        permissionStatus = findViewById(R.id.permissionStatus);

        // I show the current permission status
        updatePermissionStatus();

        // I handle the button click to request SMS permission
        requestPermissionButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(ContextCompat.checkSelfPermission(SmsActivity.this, Manifest.permission.SEND_SMS)
                        != PackageManager.PERMISSION_GRANTED){
                    ActivityCompat.requestPermissions(SmsActivity.this,
                            new String[]{Manifest.permission.SEND_SMS}, SMS_PERMISSION_CODE);
                } else {
                    Toast.makeText(SmsActivity.this, "I already have permission", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    // I check the result of the permission request
    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if(requestCode == SMS_PERMISSION_CODE){
            if(grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED){
                Toast.makeText(this, "Permission granted!", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "Permission denied", Toast.LENGTH_SHORT).show();
            }
            // I update the status text
            updatePermissionStatus();
        }
    }

    // I update the text to show if permission is granted or not
    private void updatePermissionStatus(){
        if(ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                == PackageManager.PERMISSION_GRANTED){
            permissionStatus.setText("Permission granted");
        } else {
            permissionStatus.setText("Permission not granted");
        }
    }
}
