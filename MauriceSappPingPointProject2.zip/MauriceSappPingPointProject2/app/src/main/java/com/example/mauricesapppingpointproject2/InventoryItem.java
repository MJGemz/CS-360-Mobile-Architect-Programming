package com.example.mauricesapppingpointproject2;

// Represents a single item in my inventory
public class InventoryItem {
    private int id;
    private String name;

    public InventoryItem(int id, String name) {
        this.id = id;
        this.name = name;
    }

    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
